Please look at the Server Webpage Address: http://sites.bxmc.poly.edu/~shiyunchen/WebDev/Web_Final_ShiyunChen/home.html



Blog Documentation Address: https://alicechen333.tumblr.com/post/173747525458/webdev-final-project-documentation


******Image file is too big to upload*********
