Server Webpage Address: http://sites.bxmc.poly.edu/~shiyunchen/WebDev/Web_Midterm_ShiyunChen/index.html

Blog Documentation Address: https://alicechen333.tumblr.com
